package com.example.demo.repository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import com.example.demo.model.Manga;
import java.util.List;
import org.springframework.stereotype.Repository;

@Repository
public interface MangaRepository extends CrudRepository<Manga, Long>, PagingAndSortingRepository<Manga, Long> {

    List<Manga> findById(@Param("id")long id);

    List<Manga> findAll();

    Manga save(Manga manga);

    Manga update(Manga manga);

    void deleteById(Long id);
    
}
